﻿namespace FoodDelApp
{
    public static class AppConstants
    {        
        public const string ORDERED = "ORDERED";
        public const string PREPARING = "PREPARING";
        public const string DELIVEARED = "DELIVERED";        
    }
}
