﻿using Microsoft.AspNetCore.Mvc.Rendering;

public class EditRestaurantViewModel
{
    public long RID { get; set; }
    public string Name { get; set; }
    public string Location { get; set; }
    public long OwnerId { get; set; }
    public List<SelectListItem> Owners { get; set; }
}
