﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using System.Collections.Generic;
using System.Linq;

public class EditModel : PageModel
{
    [BindProperty]
    public EditRestaurantViewModel Restaurant { get; set; }

    public List<SelectListItem> Owners { get; set; }

    public void OnGet(long id)
    {
        // Fetch the restaurant details by id
        // Example: Restaurant = _context.Restaurants.Find(id);
        // Fetch the list of owners
        Owners = GetOwners();
        Restaurant.Owners = Owners;
    }

    public IActionResult OnPost()
    {
        if (!ModelState.IsValid)
        {
            // Fetch the list of owners again in case of validation errors
            Restaurant.Owners = GetOwners();
            return Page();
        }

        // Save the restaurant details
        // Example: _context.Restaurants.Update(Restaurant);
        // _context.SaveChanges();

        return RedirectToPage("Index");
    }

    private List<SelectListItem> GetOwners()
    {
        // Fetch the list of owners from the database
        // Example: return _context.Owners.Select(o => new SelectListItem { Value = o.Id.ToString(), Text = o.Name }).ToList();
        return new List<SelectListItem>
        {
            new SelectListItem { Value = "1", Text = "Owner 1" },
            new SelectListItem { Value = "2", Text = "Owner 2" }
        };
    }
}

