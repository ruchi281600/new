﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FoodDelivery
{
    public class OrderLineData
    {
        public long MenuId { get; set; }
        public int Qty { get; set; }   
    }
}
