﻿using FoodDelivery;

namespace MMVCDemoApp1.Models
{
    public class MenuListViewModel
    {
        public List<MenuItemDTO> Items { get; set; }
    }
}
