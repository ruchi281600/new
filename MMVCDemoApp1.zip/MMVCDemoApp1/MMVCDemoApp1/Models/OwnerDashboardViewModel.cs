﻿using FoodDelivery;

namespace MMVCDemoApp1.Models
{
    public class OwnerDashboardViewModel
    {
        public List<RestaurantDTO> Restaurants { get; set; }
    }
}
