﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FoodDelivery
{
    public enum UserTypeEnum
    {
       ADMIN=1,
       OWNER=2,
       USER=3
    }    

    
}
